/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef _BLINK_EXAMPLE
#define _BLINK_EXAMPLE
namespace Blink {
void setup();
void loop();
}
#endif

/* [] END OF FILE */