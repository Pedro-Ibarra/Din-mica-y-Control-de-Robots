/* include file for rosserial Encoder example on PSoC4 "RosOnAStick"
 *
 */

#ifndef ENCODER_H
#define ENCODER_H

extern "C" {
#include "project.h"
}

namespace Encoder {
   
extern void setup();
extern void loop();


} // namespace Encoder
#endif
