/* include file for rosserial Encoder example on PSoC4 "RosOnAStick"
 *
 */

#ifndef UPDOWNCOUNT_H
#define UPDOWNCOUNT_H

extern "C" {
#include "project.h"
}

namespace UpDownCount {
   
extern void setup();
extern void loop();


} // namespace UpDownCount
#endif
