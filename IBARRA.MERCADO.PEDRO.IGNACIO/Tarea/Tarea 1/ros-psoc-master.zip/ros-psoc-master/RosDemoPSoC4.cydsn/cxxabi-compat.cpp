
extern "C" void __cxa_pure_virtual(void) ;

extern "C" void __cxa_pure_virtual(void) {
    while(1)
        ;
}
